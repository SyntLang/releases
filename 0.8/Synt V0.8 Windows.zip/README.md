# Synt
> V0.8

Go to https://docs.synt.ml/ for documentation and help for Synt.

